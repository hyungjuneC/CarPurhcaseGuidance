from django.shortcuts import render, redirect
from .models import User , Carinfo,UsersPick
from django.template import loader
from django.db.models import Q
from django.contrib import messages
from django.http import HttpResponse, HttpResponseRedirect
# Create your views here.
def post_list(request):
    person = User.objects.all()
    context={'person': person}
    return render(request, 'blog/Mainpage.html', context)
def post_list_user(request, id):
    user = User.objects.get(id=id)
    person = User.objects.all()
    carinfo = Carinfo.objects.all()
    context = {'person': person , 'user' :user , 'carinfo':carinfo}
    return render(request, 'blog/MainpageLogin.html',context)
def signup(request):
    return render(request, 'blog/signup.html')

def create(request):
    print(request.POST)
    person = User(u_id=request.POST['ID'], e_mail=request.POST['e_mail'],password=request.POST['password'],
                  phone_number=request.POST['phone_number'])

    users = User.objects.all()

    for cursor in users:
        if cursor.u_id == person.u_id:
                messages.info(request,"ID is already exist")
                return redirect('/signup')

    messages.info(request,"successfully create ID!")
    person.save()
    return redirect('/signin')

def gotosignin(request):
    return render(request,'blog/signin.html')
def signinuser(request):
    id = request.POST['ID']
    password = request.POST['password']
    person = User.objects.all()
    print(type(person))
    for cursor in person:
        if cursor.u_id == id:
            if cursor.password == password:
                return redirect('/'+str(cursor.id))
            else:
                messages.info(request,"password is wrong")
                return redirect('/signin')
    messages.info(request,"no ID exist")
    return redirect('/signin')

def Search(request,id):
    Fuel_effi = request.POST['Fuel Efficiency']
    company = request.POST['Company']
    am=request.POST['Auto/Manual']
    category = request.POST['Category']
    user = User.objects.get(id=id)
    Cars = Carinfo.objects.filter(car_fuel=Fuel_effi,car_Cate=category,car_Auto=am,car_Company=company)
    context = {'selectedcars': Cars, 'person':user }
    try:
        userpick = UsersPick.objects.get(u_id_id=id)
    except Exception as e:
        return  render(request, 'blog/Search.html',context)
    userscar = Carinfo.objects.get(id=userpick.c_id_id)

    context = {'selectedcars': Cars, 'person':user,'userscar':userscar}
    return  render(request, 'blog/Search.html',context)
def Pick(request,id,car_id):
    a = User.objects.get(id=id)
    b = Carinfo.objects.get(id=car_id)
    pick = UsersPick(u_id = a, c_id=b)
    picks = UsersPick.objects.all()
    Fuel_effi = request.POST['Fuel Efficiency']
    company = request.POST['Company']
    am=request.POST['Auto/Manual']
    category = request.POST['Category']
    Cars = Carinfo.objects.filter(car_fuel=Fuel_effi,car_Cate=category,car_Auto=am,car_Company=company)



    for p in picks:
        if p.u_id == a:
            p.c_id = b
            p.save()
            userscar = Carinfo.objects.get(id=p.c_id_id)
            context = {'selectedcars': Cars, 'person':a, 'userscar':userscar}
            return render(request, 'blog/Search.html',context)
    pick.save()
    userscar = Carinfo.objects.get(id=pick.c_id_id)
    context = {'selectedcars': Cars, 'person':a, 'userscar':userscar}
    return render(request, 'blog/Search.html',context)
def Pickinmain(request,id,car_id):
    a = User.objects.get(id=id)
    b = Carinfo.objects.get(id=car_id)
    pick = UsersPick(u_id = a, c_id=b)
    picks = UsersPick.objects.all()
    cars = Carinfo.objects.all()



    for p in picks:
        if p.u_id == a:
            p.c_id = b
            p.save()

            messages.info(request,"your pick is successfully updated.")
            context = {'carinfo': cars, 'user':a }
            return render(request, 'blog/MainPageLogin.html',context)
    pick.save()
    messages.info(request,"your pick is successfully saved")
    context = {'carinfo': Cars, 'user':a }
    return render(request, 'blog/MainPageLogin.html',context)


def edit(request, id):
    person = User.objects.get(id=id)
    context = {'person': person}
    return render(request, 'blog/UserinfoEdit.html',context)

def update(request, id):
    person = User.objects.get(id=id)
    person.ID = request.POST['ID']
    person.e_mail = request.POST['e_mail']
    person.phone_number = request.POST['phone_number']
    person.save()
    return redirect('/')

def destroy(request, id):
    people = User.objects.get(id=id)
    people.delete()
    return redirect('/')

def search(request):
    searchName = request.GET.get('name','')
    if searchName != "":
        return search_specific(request, searchName)
    template = loader.get_template('blog/Usersearch.html')
    contacts = User.objects.order_by('pk')
    context = {
        'contacts' : contacts,
    }
    return HttpResponse(template.render(context, request))

def search_specific(request, name):
    searched = User.objects.filter(name__icontains=name)
    context = {
        'name' : name,
        'contacts' : searched,
    }
    template = loader.get_template('blog/UserResult.html')
    return HttpResponse(template.render(context, request))
