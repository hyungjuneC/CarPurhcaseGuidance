from django.apps import AppConfig


class ContactslistConfig(AppConfig):
    name = 'contactslist'
