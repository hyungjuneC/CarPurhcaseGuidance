from django.conf.urls import url
from . import views
app_name='contactslist'

urlpatterns = [
    url(r'^$', views.post_list, name='post_list'),
    url(r'^(?P<id>\d+)$', views.post_list_user, name='post_list'),
    url(r'^create$', views.create),
    url(r'^edit/(?P<id>\d+)$', views.edit),
    url(r'^update/(?P<id>\d+)$', views.update),
    url(r'^delete/(?P<id>\d+)$', views.destroy),
    url(r'^search/$', views.search),
    url('search/', views.search, name='search'),
    url('search/<str:name>/', views.search_specific),
    url(r'^signup$',views.signup),
    url(r'^signin$',views.gotosignin),
    url(r'^signinuser$',views.signinuser),
    url(r'^Search/(?P<id>\d+)$',views.Search),
    url(r'^Pick/(?P<id>\d+)/(?P<car_id>\d+)$',views.Pick),
    url(r'^Pickinmain/(?P<id>\d+)/(?P<car_id>\d+)$',views.Pickinmain),
]
